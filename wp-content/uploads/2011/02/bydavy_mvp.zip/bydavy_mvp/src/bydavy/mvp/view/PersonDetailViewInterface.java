package bydavy.mvp.view;

import java.awt.event.ActionListener;
import java.awt.event.WindowListener;

public interface PersonDetailViewInterface {
	void setWindowTitle(String name);
	
	void setTextLabel(String name);

	void setTextChangeButton(String name);

	void addChangeButtonListener(ActionListener l);

	void removeChangeButtonListener(ActionListener l);

	String getNameFromTextField();
	
	void setWindowListener(WindowListener l);
	
	void display();
}
