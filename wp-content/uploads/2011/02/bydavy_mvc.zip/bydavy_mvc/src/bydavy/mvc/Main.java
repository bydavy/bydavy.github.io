package bydavy.mvc;

import bydavy.mvc.controller.PersonDetailControllerImpl;
import bydavy.mvc.model.Person;
import bydavy.mvc.view.PersonDetailViewListener;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p = new Person("Rick");
		PersonDetailViewListener controller = new PersonDetailControllerImpl(p);
		controller.getView().display();
	}

}
