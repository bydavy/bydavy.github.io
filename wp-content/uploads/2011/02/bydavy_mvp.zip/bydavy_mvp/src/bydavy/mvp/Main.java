package bydavy.mvp;

import bydavy.mvp.model.Person;
import bydavy.mvp.presenter.PersonDetailPresenter;
import bydavy.mvp.view.PersonDetailViewImpl;
import bydavy.mvp.view.PersonDetailViewInterface;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person = new Person("Rick");
		PersonDetailViewInterface view = new PersonDetailViewImpl();
		PersonDetailPresenter presenter = new PersonDetailPresenter(person, view);
		presenter.display();
	}

}
