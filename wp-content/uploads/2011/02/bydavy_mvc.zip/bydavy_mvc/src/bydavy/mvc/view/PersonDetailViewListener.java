package bydavy.mvc.view;


public interface PersonDetailViewListener {

	void changedButtonPressed();

	void windowClosed();

	PersonDetailView getView();
}
