package bydavy.mvp.view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PersonDetailViewImpl extends JPanel implements
		PersonDetailViewInterface {

	private JLabel label;
	private JTextField nameTextField;
	private JButton changeButton;
	private JFrame frame;
	private WindowListener windowListener;
	private String windowTitle;

	public PersonDetailViewImpl() {
		createUI();
	}

	private void createUI() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		this.label = new JLabel();
		add(label, BorderLayout.NORTH);

		this.nameTextField = new JTextField();
		add(nameTextField);

		this.changeButton = new JButton();
		add(changeButton);
	}

	@Override
	public void setTextLabel(String name) {
		this.label.setText(name);
	}

	@Override
	public void setTextChangeButton(String name) {
		this.changeButton.setText(name);
	}

	@Override
	public void addChangeButtonListener(ActionListener l) {
		this.changeButton.addActionListener(l);
	}

	@Override
	public void removeChangeButtonListener(ActionListener l) {
		this.changeButton.removeActionListener(l);
	}

	@Override
	public String getNameFromTextField() {
		return nameTextField.getText();
	}
	
	@Override
	public void setWindowListener(WindowListener l) {
		this.windowListener = l;
	}
	
	@Override
	public void setWindowTitle(String name) {
		this.windowTitle = name;
	}
	
	@Override
	public void display() {
		if (this.frame == null) {
			this.frame = new JFrame() {
				{
					setTitle(windowTitle);
					setLocationRelativeTo(null);
					setContentPane(PersonDetailViewImpl.this);
					setDefaultCloseOperation(DISPOSE_ON_CLOSE);
					addWindowListener(windowListener);
					pack();
				}
			};
		}

		this.frame.setVisible(true);
	}



}
