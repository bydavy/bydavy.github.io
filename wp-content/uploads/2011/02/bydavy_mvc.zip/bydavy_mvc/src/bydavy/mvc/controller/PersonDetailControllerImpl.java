package bydavy.mvc.controller;

import javax.swing.JFrame;

import bydavy.mvc.model.Person;
import bydavy.mvc.view.PersonDetailView;
import bydavy.mvc.view.PersonDetailViewListener;

public class PersonDetailControllerImpl implements PersonDetailViewListener {

	private Person model;
	private PersonDetailView view;
	
	public PersonDetailControllerImpl(Person person)
	{
		this.model = person;
		this.view = new PersonDetailView(person, this);
	}

	@Override
	public void changedButtonPressed() {
		final String newName = this.view.getNameFromTextField();
		
		if (!newName.trim().isEmpty())
		{
			this.model.setName(newName);
		}
	}
	
	@Override
	public PersonDetailView getView() {
		return this.view;
	}

	@Override
	public void windowClosed() {
		System.exit(0);
	}
}
