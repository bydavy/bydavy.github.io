package bydavy.mvp.presenter;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import bydavy.mvp.model.Person;
import bydavy.mvp.model.Person.PersonListener;
import bydavy.mvp.view.PersonDetailViewInterface;

public class PersonDetailPresenter implements PersonListener {

	private static final String LABEL = "The person name is ";
	private static final String LABEL_CHANGE_BUTTON = "Change";

	private Person model;
	private PersonDetailViewInterface view;

	public PersonDetailPresenter(Person person, PersonDetailViewInterface view) {
		this.model = person;
		this.model.addListener(this);
		this.view = view;
		bindUI();
		populateView();
	}

	private void bindUI() {
		this.view.addChangeButtonListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				final String newName = view.getNameFromTextField();

				if (!newName.trim().isEmpty()) {
					model.setName(newName);
				}
			}
		});
		this.view.setWindowListener(new WindowListener() {
			@Override
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}

			@Override
			public void windowOpened(WindowEvent e) {
			}

			@Override
			public void windowIconified(WindowEvent e) {
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
			}

			@Override
			public void windowClosing(WindowEvent e) {
			}

			@Override
			public void windowActivated(WindowEvent e) {
			}
		});
	}

	private void populateView() {
		this.view.setTextLabel(LABEL + this.model.getName());
		this.view.setTextChangeButton(LABEL_CHANGE_BUTTON);
	}

	public void display() {
		this.view.display();
	}

	@Override
	public void onPersonNameChanged() {
		this.view.setTextLabel(LABEL + this.model.getName());
	}
}
