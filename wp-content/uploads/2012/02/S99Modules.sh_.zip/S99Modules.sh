#!/bin/sh

MODULES_DIR="/lib/modules"
MODULES="usbserial.ko ftdi_sio.ko"

start_modules(){
	echo "--- Load modules ---"
	for i in $MODULES; do
		echo "Loading $i"
		insmod $MODULES_DIR/$i
	done
	
	# Create the first ttyUSB
	if [ -f /dev/ttyUSB0]; then
		mknod /dev/ttyUSB0 c 188 0
		mknod /dev/ttyUSB1 c 188 0
		mknod /dev/ttyUSB2 c 188 0
		mknod /dev/ttyUSB3 c 188 0
	fi
}

stop_modules(){
	echo "--- Unload modules ---"
	for i in $MODULES; do
		echo "Unloading $i"
		rmmod $MODULES_DIR/$i
	done	
}


case "$1" in

start)
	start_modules
	;;

stop)
	stop_modules
	;;

*)
	echo "usage: $0 { start | stop }" >&2
	exit 1
	;;

esac
